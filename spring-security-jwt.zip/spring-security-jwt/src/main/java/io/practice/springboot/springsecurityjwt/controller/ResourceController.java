package io.practice.springboot.springsecurityjwt.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import io.practice.springboot.springsecurityjwt.models.AuthenticationRequest;
import io.practice.springboot.springsecurityjwt.models.AuthenticationResponse;
import io.practice.springboot.springsecurityjwt.util.JwtUtil;

@RestController
public class ResourceController {
	
	@Autowired
	private AuthenticationManager auth;
	
	@Autowired
	private UserDetailsService service;
	
	@Autowired
	private JwtUtil util;
	
	@GetMapping("/")
	public String hello()
	{
		return "Hello !!!";
	}
	
	@GetMapping("/user")
	public String userHello()
	{
		return "Hello User!!!";
	}
	
	@GetMapping("/admin")
	public String adminHello()
	{
		return "Hello Admin!!!";
	}
	
	@PostMapping("/authenticate")
	public ResponseEntity<?> authenticate(@RequestBody AuthenticationRequest request) throws Exception
	{
		try
		{
			 auth.authenticate(new 
					UsernamePasswordAuthenticationToken(request.getUserName(), request.getPassword()));
		}
		catch(BadCredentialsException e)
		{
			throw new Exception("Incorrect username or passwd "+e);
		}
		
		final UserDetails userDetails= service.loadUserByUsername(request.getUserName());
		
		final String jwt=util.generateToken(userDetails);
		return ResponseEntity.ok(new AuthenticationResponse(jwt));
		
	}

}
