package io.practice.springboot.springsecurityjwt.util;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@Service
public class JwtUtil {
	
	private String SECRET_KEY="secret";
	
	
	public String generateToken(UserDetails details)
	{
		Map<String,Object> claim= new HashMap<>();
		return createToken(claim,details.getUsername());
	}


	private String createToken(Map<String, Object> claim, String userName) {
		return Jwts.builder().setClaims(claim).setSubject(userName).setIssuedAt(new 
				Date(System.currentTimeMillis())).setExpiration(new 
						Date(System.currentTimeMillis()+1000*60*60*3)).signWith(SignatureAlgorithm.HS256, SECRET_KEY).compact();
		
	}
	
	private Claims extractAllClaims(String token)
	
	{
		return Jwts.parser().setSigningKey(SECRET_KEY).parseClaimsJws(token).getBody();
	}
	
	public <T> T extractClaim(String token , Function<Claims, T> claimResolver)
	{
		final Claims claim= extractAllClaims(token);
		return claimResolver.apply(claim);
	}
	
	public Date extractExpiration(String token)
	{
		return extractClaim(token, Claims::getExpiration);
	}
	
	public boolean isTokenExpired(String token)
	{
		return extractExpiration(token).before(new Date());
	}
	
	public String getUserName(String token)
	{
		return extractClaim(token, Claims::getSubject);
	}
	
	public boolean validateToken(String token,UserDetails details)
	{
		String userName=getUserName(token);
		return (details.getUsername().equals(userName) && !isTokenExpired(token));
	}

}
